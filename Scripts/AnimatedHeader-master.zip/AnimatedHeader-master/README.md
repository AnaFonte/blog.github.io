
On-Scroll Animated Header
=========
A fixed header that will animate its size on scroll. The inner elements will also adjust their size with a transition.

[article on Codrops](http://tympanus.net/codrops/?p=15321)

[demo](http://tympanus.net/Blueprints/AnimatedHeader/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)